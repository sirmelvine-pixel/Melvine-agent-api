const express    = require('express');
const cors       = require('cors');
const nodemailer = require('nodemailer');
const crypto     = require('crypto');

const app  = express();
const PORT = process.env.PORT || 3000;
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '20mb' }));

// ─── ENV VARS (set in Render dashboard) ──────────────────────────
// GMAIL_USER  = your Gmail address
// GMAIL_PASS  = 16-char Google App Password
// SECRET      = any random string (e.g. "my-vault-secret-2024")
// ADMIN_CODE  = a reset code to wipe registrations if needed

const SECRET     = process.env.SECRET     || 'vault-secret';
const ADMIN_CODE = process.env.ADMIN_CODE || 'reset-vault-9999';

// ─── IN-MEMORY STORE ─────────────────────────────────────────────
const db = {
  messages:  [],          // [{id,from,name,text,image,ts,reacts}]
  otps:      {},          // {email: {code, exp}}
  tokens:    {},          // {token: {email, name, exp}}
  slots:     [],          // registered emails: max 2.  [email1, email2]
  nameMap:   {},          // {email: 'him'|'her'}
};

// ─── EMAIL ───────────────────────────────────────────────────────
function getMailer() {
  if (!process.env.GMAIL_PASS) return null;
  return nodemailer.createTransport({
    service: 'gmail',
    auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_PASS },
  });
}

async function sendCodeEmail(to, code) {
  const ml = getMailer();
  if (!ml) { console.log('[OTP]', to, '=', code, '(no email config)'); return false; }
  try {
    await ml.sendMail({
      from: `"Our Secret Place 🌙" <${process.env.GMAIL_USER}>`,
      to,
      subject: 'Your sign-in code ✦',
      html: `<div style="font-family:Georgia,serif;max-width:440px;margin:0 auto;padding:40px 28px;background:#06041a;color:#e0daf0;border-radius:18px;">
        <div style="text-align:center;margin-bottom:26px;">
          <div style="font-size:38px;margin-bottom:10px;">🌙</div>
          <h2 style="font-family:Georgia,serif;font-size:24px;font-weight:400;color:#f0e8d0;margin:0 0 4px;letter-spacing:1px;">Our Secret Place</h2>
          <p style="color:#8880b8;font-style:italic;margin:0;font-size:14px;">where only we exist</p>
        </div>
        <p style="font-size:14px;color:#9090b0;line-height:1.7;margin-bottom:20px;">Here is your sign-in code. It expires in 10 minutes.</p>
        <div style="text-align:center;margin:28px 0;">
          <div style="display:inline-block;padding:18px 32px;letter-spacing:14px;font-size:42px;font-weight:700;color:#f0e8d0;background:rgba(180,60,100,0.15);border:1px solid rgba(180,60,100,0.4);border-radius:14px;">${code}</div>
        </div>
        <p style="font-size:12px;color:#504878;text-align:center;font-style:italic;">Never share this code. ✦</p>
      </div>`,
    });
    console.log('[OTP] Sent to', to);
    return true;
  } catch(e) {
    console.error('[OTP] Error:', e.message);
    console.log('[OTP] Code for', to, '=', code);
    return false;
  }
}

// ─── HELPERS ─────────────────────────────────────────────────────
const genCode  = () => String(Math.floor(100000 + Math.random() * 900000));
const genToken = (email) => crypto.createHmac('sha256', SECRET).update(email + Date.now() + Math.random()).digest('hex');

function authMiddleware(req, res, next) {
  const token = req.headers['x-token'];
  const email = (req.headers['x-email'] || '').toLowerCase().trim();
  const sess  = db.tokens[token];
  if (!sess || Date.now() > sess.exp || sess.email !== email)
    return res.status(401).json({ error: 'Session expired. Please sign in again.' });
  req.who = sess;
  next();
}

// ─── ROUTES ──────────────────────────────────────────────────────
app.get('/', (req, res) => res.json({
  ok: true,
  vault: 'Our Secret Place 🌙',
  slots: db.slots.length + '/2 registered',
  messages: db.messages.length,
  email: process.env.GMAIL_PASS ? 'configured ✅' : 'needs GMAIL_PASS ⚠️',
}));

// REQUEST OTP — registers email if slot available
app.post('/otp/request', async (req, res) => {
  const email = (req.body.email || '').toLowerCase().trim();
  if (!email || !email.includes('@')) return res.status(400).json({ error: 'Invalid email' });

  // If vault is full and this email isn't in it
  if (db.slots.length >= 2 && !db.slots.includes(email))
    return res.status(403).json({ error: 'This vault already has 2 people in it. Ask your partner to reset or use the right email.' });

  // Register if new
  if (!db.slots.includes(email)) {
    db.slots.push(email);
    db.nameMap[email] = db.slots.length === 1 ? 'him' : 'her';
    console.log('[register]', email, 'as', db.nameMap[email]);
  }

  const code = genCode();
  db.otps[email] = { code, exp: Date.now() + 10 * 60 * 1000 };
  const sent = await sendCodeEmail(email, code);
  res.json({ ok: true, sent, hint: sent ? 'Check your email' : 'Check server logs for code (email not configured)' });
});

// VERIFY OTP → session token
app.post('/otp/verify', (req, res) => {
  const email = (req.body.email || '').toLowerCase().trim();
  const code  = (req.body.code  || '').trim();
  const entry = db.otps[email];
  if (!entry || Date.now() > entry.exp) return res.status(400).json({ error: 'Code expired. Request a new one.' });
  if (entry.code !== code)             return res.status(400).json({ error: 'Wrong code. Try again.' });
  delete db.otps[email];
  const token = genToken(email);
  const name  = db.nameMap[email] || 'him';
  db.tokens[token] = { email, name, exp: Date.now() + 30 * 24 * 60 * 60 * 1000 };
  res.json({ ok: true, token, name, email });
});

// GET messages
app.get('/messages', authMiddleware, (req, res) => {
  const since = parseInt(req.query.since) || 0;
  const list  = since ? db.messages.filter(m => new Date(m.ts).getTime() > since) : db.messages;
  res.json({ ok: true, messages: list });
});

// POST message
app.post('/messages', authMiddleware, (req, res) => {
  const { id, text, image, ts } = req.body;
  if (!text && !image) return res.status(400).json({ error: 'Empty message' });
  if (id && db.messages.find(m => m.id === id)) return res.json({ ok: true, dup: true });
  const msg = {
    id:     id || crypto.randomUUID(),
    from:   req.who.email,
    name:   req.who.name,
    text:   (text || '').trim(),
    image:  image || null,
    ts:     ts || new Date().toISOString(),
    reacts: [],
  };
  db.messages.push(msg);
  if (db.messages.length > 2000) db.messages = db.messages.slice(-2000);
  res.json({ ok: true, message: msg });
});

// REACT
app.post('/messages/:id/react', authMiddleware, (req, res) => {
  const msg = db.messages.find(m => m.id === req.params.id);
  if (!msg) return res.status(404).json({ error: 'Not found' });
  const { emoji } = req.body;
  const idx = msg.reacts.findIndex(r => r.email === req.who.email && r.emoji === emoji);
  if (idx >= 0) msg.reacts.splice(idx, 1);
  else msg.reacts.push({ email: req.who.email, name: req.who.name, emoji });
  res.json({ ok: true, reacts: msg.reacts });
});

// DELETE message
app.delete('/messages/:id', authMiddleware, (req, res) => {
  const idx = db.messages.findIndex(m => m.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: 'Not found' });
  if (db.messages[idx].from !== req.who.email) return res.status(403).json({ error: 'Not your message' });
  db.messages.splice(idx, 1);
  res.json({ ok: true });
});

// ADMIN RESET — wipe all registrations (use if wrong email registered)
app.post('/admin/reset', (req, res) => {
  if (req.body.code !== ADMIN_CODE) return res.status(403).json({ error: 'Wrong admin code' });
  db.slots   = [];
  db.nameMap = {};
  db.tokens  = {};
  db.otps    = {};
  console.log('[admin] vault reset');
  res.json({ ok: true, message: 'Vault registrations cleared. First 2 emails to sign in will be registered.' });
});

// GET vault status (who is registered)
app.get('/status', (req, res) => {
  res.json({
    ok: true,
    slots: db.slots.length,
    full: db.slots.length >= 2,
    registeredEmails: db.slots,
  });
});

app.listen(PORT, () => {
  console.log(`Love Vault API on :${PORT}`);
  console.log(`Email: ${process.env.GMAIL_PASS ? 'ready' : 'needs GMAIL_PASS env var'}`);
  console.log(`Admin reset code: ${ADMIN_CODE}`);
});
