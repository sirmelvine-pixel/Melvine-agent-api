# Bill's WhatsApp AI Agent — Deployment Guide

## What you'll have when done:
Message your WhatsApp bot things like:
- "What's on my schedule today?"
- "Add a meeting with the TrueHR team tomorrow at 2pm"
- "What are my high priority tasks?"
- "Add a task: send Manivor quote to Ministry, high priority"
- "Give me my daily briefing"
- "Mark task 1 as done"

---

## STEP 1 — Get a FREE Twilio WhatsApp sandbox (5 mins)

1. Go to https://www.twilio.com and create a free account
2. In the Console, go to **Messaging → Try it out → Send a WhatsApp message**
3. Follow the instructions to join the sandbox — you'll send a WhatsApp message like:
   `join <word-word>` to the Twilio sandbox number
4. Note your **Twilio sandbox number** (looks like +14155238886)
5. No credit card needed for the sandbox

---

## STEP 2 — Deploy the bot FREE on Railway (5 mins)

1. Go to https://railway.app and sign up with GitHub (free)
2. Click **New Project → Deploy from GitHub repo**
   - OR click **New Project → Deploy from template** and upload this folder
3. Add these **Environment Variables** in Railway settings:
   ```
   ANTHROPIC_API_KEY = your-anthropic-api-key-here
   PORT = 3000
   ```
4. Railway will give you a live URL like:
   `https://bill-agent-production.up.railway.app`

---

## STEP 3 — Connect Twilio to your Railway bot (2 mins)

1. Back in Twilio Console, go to your WhatsApp sandbox settings
2. In **"When a message comes in"**, paste your Railway URL + `/whatsapp`:
   ```
   https://bill-agent-production.up.railway.app/whatsapp
   ```
3. Set method to **HTTP POST**
4. Click Save

---

## STEP 4 — Test it!

Send a WhatsApp message to your Twilio sandbox number:
```
What's on my schedule today?
```
You should get an AI reply within a few seconds! 🎉

---

## What the bot can do

| Say this | Bot does this |
|---|---|
| "What's on today?" | Lists today's events |
| "Add meeting with James tomorrow at 3pm" | Adds event to calendar |
| "What are my tasks?" | Lists open tasks by priority |
| "Add task: prepare investor deck, high priority" | Creates new task |
| "Give me my briefing" | Full AI morning briefing |
| "Mark task done: send Manivor quote" | Marks task complete |
| Anything else | General AI assistant response |

---

## Get your Anthropic API Key

1. Go to https://console.anthropic.com
2. Click **API Keys → Create Key**
3. Copy it into Railway as `ANTHROPIC_API_KEY`

---

## Upgrade to your real WhatsApp number (optional)

Once you're happy with the bot on the sandbox, you can apply for a real
WhatsApp Business API number through Twilio (paid, ~$5/month).
This lets clients message YOUR actual WhatsApp number.

---

Built with ❤️ by Claude for Mwesigwa Bill Melvine
