// ============================================================
// Bill's WhatsApp AI Agent — Node.js + Twilio + Claude
// ============================================================
// Deploy FREE on Railway.app in ~10 minutes (see README below)
// ============================================================

const express = require('express');
const bodyParser = require('body-parser');
const Anthropic = require('@anthropic-ai/sdk');

const app  = express();
const PORT = process.env.PORT || 3000;
const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// ── IN-MEMORY STORE (replace with a database for production) ──
// Stores events, tasks, and conversation history per user
const store = {
  events: [],
  tasks:  [],
  history: {},   // phone → [{role,content}]
};

// Seed some starter data
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};

store.events = [
  { id:1, title:"Team Standup",          date: today(), time:"09:00", location:"Zoom"        },
  { id:2, title:"TrueHR Client Demo",    date: today(), time:"11:30", location:"Google Meet" },
];
store.tasks = [
  { id:1, title:"Finalise TrueHR pitch deck",        priority:"high", done:false },
  { id:2, title:"Send Manivor quote to Ministry",    priority:"high", done:false },
  { id:3, title:"Review eLearning content",          priority:"med",  done:false },
  { id:4, title:"Schedule team training session",    priority:"med",  done:false },
];

// ── HELPERS ──
function getDateStr() {
  return new Date().toLocaleDateString('en-UG', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
}
function getTodayEvents() {
  return store.events.filter(e => e.date === today()).sort((a,b) => a.time.localeCompare(b.time));
}
function getOpenTasks() {
  return store.tasks.filter(t => !t.done);
}
function buildContext() {
  const te = getTodayEvents();
  const ot = getOpenTasks();
  return `You are Bill Mwesigwa's personal WhatsApp AI agent. Bill is Head of Systems at TrueHR (HR SaaS company) and manages Manivor Investments Limited (general supplies company) in Uganda.

TODAY: ${getDateStr()}

TODAY'S EVENTS (${te.length}):
${te.length ? te.map(e => `  ${e.time} — ${e.title} @ ${e.location}`).join('\n') : '  None scheduled'}

ALL UPCOMING EVENTS:
${store.events.slice(-20).map(e => `  ${e.date} ${e.time} — ${e.title}`).join('\n') || '  None'}

OPEN TASKS (${ot.length}):
${ot.map(t => `  [${t.priority.toUpperCase()}] ${t.title}`).join('\n') || '  None'}

INSTRUCTIONS:
- You respond via WhatsApp — keep replies SHORT and scannable (use line breaks, emojis sparingly)
- When asked to ADD AN EVENT, respond conversationally AND append on a new line:
  ADD_EVENT:{"title":"...","date":"YYYY-MM-DD","time":"HH:MM","location":"..."}
- When asked to ADD A TASK, respond AND append:
  ADD_TASK:{"title":"...","priority":"high|med|low"}
- When asked to COMPLETE A TASK, respond AND append:
  DONE_TASK:{"id":NUMBER}
- When asked for SCHEDULE or TODAY, list today's events clearly
- When asked for TASKS, list open tasks by priority
- When asked for BRIEFING, give a sharp morning summary
- Always address him as Bill
- Be warm, concise, and smart. This is his personal assistant.`;
}

// ── COMMAND PROCESSING ──
function processCommands(text) {
  const results = [];

  // ADD EVENT
  const em = text.match(/ADD_EVENT:(\{[^}]+\})/);
  if (em) {
    try {
      const ev = JSON.parse(em[1]);
      ev.id = Date.now();
      if (!ev.location) ev.location = 'TBC';
      store.events.push(ev);
      results.push(`✅ Event saved: "${ev.title}" on ${ev.date} at ${ev.time}`);
    } catch(e) { results.push('⚠️ Could not parse event data.'); }
  }

  // ADD TASK
  const tm = text.match(/ADD_TASK:(\{[^}]+\})/);
  if (tm) {
    try {
      const t = JSON.parse(tm[1]);
      t.id = Date.now(); t.done = false;
      store.tasks.unshift(t);
      results.push(`✅ Task saved: "${t.title}" [${t.priority}]`);
    } catch(e) { results.push('⚠️ Could not parse task data.'); }
  }

  // DONE TASK
  const dm = text.match(/DONE_TASK:(\{[^}]+\})/);
  if (dm) {
    try {
      const { id } = JSON.parse(dm[1]);
      const t = store.tasks.find(t => t.id === Number(id));
      if (t) { t.done = true; results.push(`✅ Marked done: "${t.title}"`); }
    } catch(e) {}
  }

  return results;
}

// Strip command tokens from display text
function cleanText(text) {
  return text
    .replace(/ADD_EVENT:\{[^}]+\}/g, '')
    .replace(/ADD_TASK:\{[^}]+\}/g, '')
    .replace(/DONE_TASK:\{[^}]+\}/g, '')
    .trim();
}

// ── TWILIO WEBHOOK ──
app.post('/whatsapp', async (req, res) => {
  const from    = req.body.From || '';
  const inbound = (req.body.Body || '').trim();

  if (!inbound) {
    res.set('Content-Type', 'text/xml');
    return res.send('<Response></Response>');
  }

  console.log(`📩 [${from}]: ${inbound}`);

  // Init history for this number
  if (!store.history[from]) store.history[from] = [];

  // Add user message to history
  store.history[from].push({ role: 'user', content: inbound });

  // Keep last 12 messages for context
  const recentHistory = store.history[from].slice(-12);

  let replyText = "I'm having a moment, Bill. Please try again in a few seconds.";

  try {
    const response = await client.messages.create({
      model:      'claude-sonnet-4-20250514',
      max_tokens: 600,
      system:     buildContext(),
      messages:   recentHistory,
    });

    const rawReply = response.content.map(c => c.text || '').join('');

    // Process any commands embedded in the reply
    const cmdResults = processCommands(rawReply);

    // Clean the display text
    const displayText = cleanText(rawReply);

    // Build final reply
    replyText = displayText;
    if (cmdResults.length > 0) {
      replyText += '\n\n' + cmdResults.join('\n');
    }

    // Add assistant reply to history
    store.history[from].push({ role: 'assistant', content: rawReply });

  } catch (err) {
    console.error('Claude API error:', err.message);
  }

  // Respond via Twilio TwiML
  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>${escapeXml(replyText)}</Message>
</Response>`;

  res.set('Content-Type', 'text/xml');
  res.send(twiml);
});

function escapeXml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── HEALTH CHECK ──
app.get('/', (req, res) => {
  res.json({
    status: 'running',
    agent:  "Bill's WhatsApp AI Agent",
    events: store.events.length,
    tasks:  store.tasks.length,
    today:  getTodayEvents().length + ' events today',
  });
});

app.listen(PORT, () => {
  console.log(`🤖 Bill's WhatsApp Agent running on port ${PORT}`);
});
